package com.company;

/**
 * Created by corbot on 2/27/2016.
 */
public class CharacterProfile {

    private String playerName;
    private String playerGender;
    private String playerRace;

    public CharacterProfile(String playerName, String playerGender, String playerRace) {
        this.playerName = playerName;
        this.playerGender = playerGender;
        this.playerRace = playerRace;
    }


}
